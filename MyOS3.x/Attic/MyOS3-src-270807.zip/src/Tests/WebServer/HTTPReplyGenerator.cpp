/***************************************************************************
 HTTPReplyGenerator.cpp  -  description
 -------------------
 begin                : Tue Mar 26 2002
 copyright            : (C) 2002 by Jeroen van Bemmel
 email                : jeroen@thebem.localdomain
 ***************************************************************************/
#include "HTTPReplyGenerator.h"
// #include "WebServerApplication.h"
#include "buffer.h"
#include "IO/OStream.h"
#include "Core/IScriptable.h"

namespace MyOS
{
namespace Tests
{

void HTTPReplyGenerator::generateReply(IDirectory* base, const char* const url,
        IO::OStream& htmlout)
{
    htmlout.printf("<html>\n<body>");

    if (url[2] != '\0')
    { // not "./"
        IInterface *result;
        if (const char *restpath = base->findNode( myos_name_t(url), VERSION::ANY(), result ))
        {
            if (*restpath!='\0')
            {
                Core::IScriptable* s = result->getScriptable();
                if (s && s->get( restpath, 0, htmlout ) < 0)
                { // could check if call is supported before doing this
                    htmlout.printf( "<ERROR> Call not supported: %s", restpath );
                }
                goto done;
            }
            else if (!(base = result->castTo<IDirectory>()))
            {
                htmlout.printf( "<ERROR> Not a directory: %s", url );
                goto done;
            }
        }
    }

    base->onAllNodes( *this, &htmlout, 0 );
done:
    htmlout.printf( "\n</body>\n</html>\n" );
}

// I_DirectoryCallback
bool
HTTPReplyGenerator::onIterate( const myos_name_t& name, IInterface &i, void *context )
{
    // LOG( WebServer, "onIterate name=%s", name );
    IO::OStream* out = (IO::OStream *) context;
    if (strcmp(name,".")!=0)
    {
        if (i.castTo<IDirectory>()!=0)
        {
            // dont add '<IMG BORDER=0 SRC=\"/dir.gif\" ALT=\"[DIR]\">' yet, triggers more requests
            out->printf( "<A HREF=\"./%n/\">./%n</A><br>\n", &name, &name );
        }
        else
        {
            myos_name_t ifname( i.getUUID() );
            out->printf( "<A HREF=\"./%n.xml\">XML</A><br>\n", &ifname );
        }
    }
    return true;
}

}} // namespace

#ifndef ITiming_H
#define ITiming_H
#include "Core/IInterface.h"

using MyOS::Core::IInterface;

#include "timetypes.h"

namespace MyOS {
namespace Timer {

/**
 * Provides a timer facility
 */
INTERFACE( ITiming, "cd5a76a0-bf79-4750-8356-9f8a0627465a" )

    /**
     * Returns the current time in the given units
     * 
     * @note Could be placed in a different interface, its unrelated
     */
	virtual u32 now(ETimeUnit units) = 0;

    /**
     * Initializes a new timer
     * @param timer  - timer to initialize
     * @param target - callback handler
     */
	virtual myos_result_t initTimer(timer_t& timer, ITimerTarget& target) = 0;

	/**
	 * (re)starts the given timer
	 * @param timer   - timer to (re)start
	 * @param afterUs - period(us) to wait before firing
	 */
	virtual myos_result_t startTimer(timer_t& timer, u32 afterUs) = 0;

	/**
	 * Cancels the given timer (no-op when not running)
	 * @param timer - timer to cancel  
	 */
	virtual myos_result_t cancelTimer(timer_t& timer) = 0;

	/**
	 * Triggers the given timer, causing a call to ITimerTarget#onTimer
	 * If the timer was set, it is now cancelled 
	 */
	virtual myos_result_t triggerTimer(timer_t& timer) = 0;

	/**
	 * Releases the resources associated with the given timer.
	 * @param timer - timer to release, handle becomes invalid after this call
	 */
	virtual myos_result_t freeTimer(timer_t& timer) = 0;

};

}
} // namespaces
#endif

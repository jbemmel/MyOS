#ifndef TIMEREVENT_H
#define TIMEREVENT_H

#include "timetypes.h"
#include "PriorityHeap.h"
#include "TimerImpl.h"

namespace MyOS { namespace Timer {
  
/**
 * Designed to be allocated by users of the ITiming interface
 */  
class TimerEvent : public HeapItem  
{
	/* ITimerTarget* */ u32 target;

	/**
	 * moment in time (measured in RDTSC clockticks) when this timer fires
	 */
	u64 firesAt;
	
public:
	// Sets the callback and clears the cancel flag (assumes bit0 not set)
	inline void setCallback( ITimerTarget& cb ) {
		this->target = (u32) &cb;
	}

/**
 * Callback function to be implemented by classes that use this functionality
 * 
 * This function is called by the timer when the set expiration time for
 * the event passes (or has passed).
 * 
 * It is called in an *IRQ* context, so be careful about the methods you call.
 * In particular, don't call 'schedule', 'reschedule' or 'trigger'
 * as defined below, but used the 'onTimer_xx' variants instead
 */
	inline void doCallback() {
		((ITimerTarget*) (target&~1))->onTimer(  );
	}
   
protected:
   // caller of 'onTimer' and other methods here
   friend class TimerImpl;
   friend class ITimingImpl;
   
   /**
    * Canceling is implemented as setting a flag, and cleaning up canceled events from 
    * the top of the heap. This has some implications:
    * 
    * - every 'pop' needs to continue until the top item is not canceled, or the heap is empty
    * - before push, cancel flag needs to be cleared
    * - does not work when item to be canceled is at the top (need to pop then, until no more canceled)
    */ 
   inline void markCanceled()     { target |= 1; }
   inline int isCanceled() const  { return target & 1; }
   inline void uncancel()         { target &= ~1; }

   // can be called by subclasses (except while in onTimer())
   inline void schedule( u32 afterUs ) {
      TimerImpl::instance->addEvent( *this, afterUs );  
   }

   // can be called by subclasses (except while in onTimer())
   //inline void remove() {
   //   TimerImpl::instance->cancelEvent( *this, true );    // remove 
   //}

   // can be called by subclasses (except while in onTimer())
   inline void trigger() {      
      TimerImpl::instance->triggerEvent( *this );  
   }
   
   inline void cancel() {
       TimerImpl::instance->cancelEvent( *this );  
   }
   
   inline void* operator new( size_t );
   inline void operator delete( void* );

   // private Constructor, prevent subclassing
private:   
   inline TimerEvent( ) : HeapItem(), target(0) {}     // not initializing firesAt
};
  
}} // namespace

#endif

#ifndef IMultiThreading_H
#define IMultiThreading_H
#include "Core/IInterface.h"

using MyOS::Core::IInterface;

#include "Exceptions/MyOSExceptions.h"
#include "NVPAIR.h"

namespace MyOS
{
namespace MultiThreading
{

class Thread;

class IRunnable
{
public:
    virtual int run(NVPAIR params[]) = 0;
};

/**
 * Interface to create threads
 */
INTERFACE( IMultiThreading, "3db93a90-a7c1-41df-9029-4e3895f9fab2" )

virtual Thread& createThread(u32 stackorder, u32 allocOrder=0) 
    throw(Exceptions::OutOfMemoryException) = 0;

virtual myos_result_t listThreads(IO::OStream& out) const = 0;

};

}
} // namespaces
#endif

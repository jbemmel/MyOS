#ifndef IMultiProcessing_H
#define IMultiProcessing_H

#include "Core/IInterface.h"
#include "Exceptions/MyOSExceptions.h"

using MyOS::Core::IInterface;

namespace MyOS {
namespace MultiProcessing {


class Process;

using Exceptions::OutOfMemoryException;

/**
 * Interface for creating new processes
 */
INTERFACE( IMultiProcessing, "2c902461-c339-4008-ad73-84732a7c9f70" )

    /**
     * Creates a new process (with a new main thread)
     * 
     * @param log2MaxAllocPages - log2 of the maximum allocatable size of memory blocks, in pages
     * 
     * @throw OutOfMemoryException
     */
	virtual Process& createProcess(u32 log2MaxAllocPages ) 
		throw(OutOfMemoryException) = 0;

	virtual myos_result_t listProcesses(IO::OStream& out) const = 0;

};

}
} // namespaces
#endif

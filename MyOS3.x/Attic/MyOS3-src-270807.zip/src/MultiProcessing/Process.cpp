#include "Init/MyOSCoreContainerDefs.h"
// #ifdef MP_IN_CORE

#include "Process.h"
#include "MultiProcessing/MPComponent.h"

#include "MultiThreading/IThread.h"    // currentThread
#include "MM/Physical/PBT.h"           // PBT
#include "MM/Virtual/GDT.h"

#include "MM/new.h"  // placement new
#include "debug.h"

namespace MyOS { namespace MultiProcessing {

using namespace MM;

// static
Process* Process::currentProcess = 0;   // ASMNAME "curProcess"

void*
Process::operator new( size_t ) throw (OutOfMemoryException)
{
   physadr_t adr;
   void *m = MPComponent::getInstance().iVirtualMemory->allocPage( adr );
   // This should have been clear already! (but it usually isn't)
   // memset_aligned( m, 0, _4KB );   
   return m;
}

void
Process::operator delete( void* p ) {
   MPComponent::getInstance().iVirtualMemory->freePage(p);
}

// static
void
Process::initOnce()     // INITSECTION
{
   currentProcess = new Process();   
}

Process::Process()   // INITSECTION, used for P(0)
: mainThread( Thread::currentThread() )
, parent(0)
{
   pbt = &PBT::getCurrentPBT();
   tss.initOnce();

   mainThread.homeContext = this;
   mainThread.visitedContext = this;
}

Process::Process( Process& _parent, u32 blockOrder )
: mainThread( MPComponent::getInstance().iMultiThreading->createThread(blockOrder) )
, parent( &_parent )
{
   // DPRINTK( "\nCreating new process at %x", this );
   // Moved to Thread::init (set to curProcess)
   // mainThread.homeContext = mainThread.visitedContext = this;

   // allocate a page for the PBT (this copies the appropriate parent process entries)
   // Since the PBT is allocated from kernel memory, this address is valid for any process
   physadr_t m;
   pbt = new ( MPComponent::getInstance().iVirtualMemory->allocPage(m) ) PBT(m);

   // NOTE: MainThread is created while still in context of *PARENT* process !!
   // CANNOT DO THIS: Need parameters on stack of new thread, in start()
   // tss.initialize( pbt, mainThread );

   // add yourself to parent process' linked list (at head)
   next = parent->subprocesses;
   parent->subprocesses = this;
   
   mainThread.homeContext = this;
   mainThread.visitedContext = this;   
}

/**
 * This method is called in the context of another process
 * when the main thread is (automatically) destroyed
 */
Process::~Process()
{
   if (parent && pbt) {    // free PBT, not for P0
      MPComponent::getInstance().iVirtualMemory->freePage( pbt );
      pbt = 0;         
   }   
}

bool
Process::start( IRunnable& runner, NVPAIR params[], size_t paramCount )
{
   DPRINTK( "\nProcess::start this=%x mainThread=%x", this, &mainThread );
   
   /*
    * Dont use interface, as we still need to initialize the TSS
    * Drawback is more tight integration (could redesign interface a bit)
    * 
   MPComponent::getInstance().iMultiThreading->startThread( 
      mainThread, runner, params 
   );
   */
   mainThread.init( runner, params, paramCount );
   tss.initialize( pbt, mainThread );     // uses mainThread.ESP
   mainThread.start();
   return true;
}

void 
Process::removeThread( Thread& t )
{
   // perhaps maintain counter, and delete iff count==0 ?
   if (&t == &mainThread) {
      DPRINTK( "\nMainThread destroyed, deleting process..." );
      delete this;
   }  
}
  
void 
Process::taskSwitch()
{
    ASSERTION( this != currentProcess, E_CRITICAL );
    // DPRINTK( "taskSwitch" );
    
    /***
     * This is **REALLY TRICKY** CODE!!!
     * 
     * Think about it. TR points at both the old and the new TSS at the moment
     * of the task switch. That means the register values get saved in the
     * TSS of the *next* process (being switched to). However, CR3 does not get 
     * stored...
     * 
     * Then CR3 is updated using the value in the new TSS, so a context switch
     * is effective, but all registers are reloaded with their previous values...
     * And, I need to store the values of ECX, EDX, EBX in the new TSS, to keep
     * them around when the reverse switch happens. Does this go OK with N processes
     * intermixing??
     */      
    using MM::GDT;
    
    SegmentDescriptor &tssD = GDT::getEntry( 4 );     // XX hardcoded, assumes TSS at index 4 (see TSS.cpp)
    tssD.setBase( (u32) this );
    tssD.setAttributes( SEG_TSS );   // clear 'active' bit
    
    this->tss.ESP = Processor::ESP();   // make sure we can return
    
    // GCC caller-save registers: EBX (already saved), EDI, ESI, EBP
    this->tss.EDI = Processor::EDI();
    this->tss.ESI = Processor::ESI();
    this->tss.EBP = Processor::EBP();
    
    // XX hardcoded $32 == 4*8, TODO should be Selector::switchTo()
    ASMVOLATILE(
       ".globl _tss_eip     ;" // used in TSS constructor
       "ljmp $32,$0         ;" // make task switch, this stores in *next* TSS
                               // could also do a far call, then backlink would get filled in and task
                               // is considered nested (both marked busy) and NT flag bit is set
                               // when NT is set, iret causes a taskswitch
                               // This can also be used as task scheduling mechanism (see
                               // http://www.embedded.com/columns/technicalinsights/55301875?_requestid=27221
       "_tss_eip:           ;" // used in TSS to initialize EIP
       // "sti                 ;" // if process initially has interrupts disabled (no need every time)
       : : : "memory" );
    
    // Could also do this just before jumping...
    currentProcess = this;
}


}} // namespace

// #endif   // MP_IN_CORE

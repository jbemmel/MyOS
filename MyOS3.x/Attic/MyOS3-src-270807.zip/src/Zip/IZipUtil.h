#ifndef IZipUtil_H
#define IZipUtil_H
#include "Core/IInterface.h"

using MyOS::Core::IInterface;

namespace MyOS {
namespace Zip {

class IZipUtil : public IInterface {
public:
	static const uuid_t ID;

	// public for Component, could be friend if containment was fixed...
	inline IZipUtil(MyOS::Core::IComponent& c, VERSION v) :
		IInterface(c, v, ID) {
	}

	virtual myos_result_t unzip(const buffer& zipped, buffer& result) const = 0;
};

}
} // namespaces
#endif

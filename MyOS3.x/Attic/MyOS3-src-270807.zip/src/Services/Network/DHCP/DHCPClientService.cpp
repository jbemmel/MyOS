#include "Context/IContext.h"
#include "DHCPClientService.h"

#include "Networking/IP/IIPLayer.h"
#include "MM/IVirtualMemory.h"
#include "Timer/ITiming.h"
#include "MultiThreading/IMultiThreading.h"

namespace MyOS
{
namespace Services
{
namespace Network
{
namespace DHCP
{
DHCPClientService* DHCPClientService::instance INITINSTANCE;

DHCPClientService::DHCPClientService(MyOS::Core::IContainer& container) throw() :
    IService(container, VERSION(1, 1), ID(), (IService*&) instance )
{
}

myos_result_t DHCPClientService::initialize(Context::IContext& context,
        NVPAIR params[])
{
    myos_result_t r;
    r = context.lookup(myos_name_t(IVirtualMemory::ID() ),
            (IInterface*&) iVirtualMemory );
    if (r!=E_MYOS_SUCCESS)
        return E_MYOS_E_MISREQINTF;

    r = context.lookup(myos_name_t(ITiming::ID() ), (IInterface*&) iTiming );
    if (r!=E_MYOS_SUCCESS)
        return E_MYOS_E_MISREQINTF;

    r = context.lookup(myos_name_t(IMultiThreading::ID() ),
            (IInterface*&) iMultiThreading );
    if (r!=E_MYOS_SUCCESS)
        return E_MYOS_E_MISREQINTF;

    r = context.lookup(myos_name_t(IIPLayer::ID() ), (IInterface*&) iIPLayer );
    if (r!=E_MYOS_SUCCESS)
        return E_MYOS_E_MISREQINTF;

    allocator.init( *iVirtualMemory, 0);

    r = iIPLayer->registerService( *this);

    return r;
}

/** Also called after partial init() that fails */
myos_result_t DHCPClientService::deinitialize(Context::IContext& context)
{

    if (iIPLayer)
        iIPLayer->removeService( *this);

    // if (iIPLayer) ((IInterface*)iIPLayer)->release();    

    // if (iTiming) ((IInterface*)iTiming)->release();    

    // if (iVirtualMemory) ((IInterface*)iVirtualMemory)->release();    

    return E_MYOS_SUCCESS;
}

}
}
}
} // namespaces

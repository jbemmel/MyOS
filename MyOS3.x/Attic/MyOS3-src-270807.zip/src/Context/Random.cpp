#include "Random.h"

  /// Enum to prevent statics
  enum {
     A = 48271,
     M = 2147483647,
     Q = M / A,
     R = M % A,
  };

/**
 * Construct with initialValue for the state.
 */
Random::Random( int initialValue )
{
   if( initialValue < 0 )
      initialValue += M;

   state = (initialValue != 0) ? initialValue : 1;
}

/**
 * Return a pseudorandom int, and change the
 * internal state.
 */
int Random::randomInt( )
{
   int tmpState = A * ( state % Q ) - R * ( state / Q );
   state = ( tmpState >= 0 ) ? tmpState : (tmpState + M);
   return state;
}

/**
 * Return a pseudorandom double in the open range 0..1
 * and change the internal state.
 */
double Random::random0_1( )
{
   return (double) randomInt( ) / M;
}

/**
 * Return an int in the closed range [low,high], and
 * change the internal state.
 */
int Random::randomInt( int low, int high )
{
   double partitionSize = (double) M / ( high - low + 1 );

   return (int) ( randomInt( ) / partitionSize ) + low;
}

#ifndef IContext_H
#define IContext_H
#include "Core/IInterface.h"

using MyOS::Core::IInterface;

namespace MyOS {
namespace Context {

INTERFACE( IContext, "bdf79a36-5871-11d6-858d-0010a708e02e" )

	virtual myos_result_t add(IInterface& intf, myos_name_t* altname=0) = 0;

	virtual myos_result_t remove(IInterface& intf) = 0;

	/**
	 * @param name - typically an UUID, but may be any name in general
	 */
	virtual myos_result_t lookup(const myos_name_t& name, IInterface*& result) const = 0;

	virtual myos_result_t enumerate(IO::OStream& out) const = 0;

	virtual myos_result_t copy(IContext& to) const = 0;

};

}
} // namespaces
#endif

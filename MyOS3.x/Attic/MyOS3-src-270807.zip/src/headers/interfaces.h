#ifndef INTERFACE_FWD_DECLS_H
#define INTERFACE_FWD_DECLS_H

/**
 * Forward declarations of all interfaces
 */

namespace MyOS
{
namespace MM
{
    class IVirtualMemory;
}

namespace MultiThreading
{
    class IMultiThreading;
}

namespace Timer
{
    class ITiming;
}

namespace Networking
{
  namespace IP
  {
  class IIPLayer;
  }
}

namespace Drivers {
    class IDriverManager;
}

} // MyOS

#endif

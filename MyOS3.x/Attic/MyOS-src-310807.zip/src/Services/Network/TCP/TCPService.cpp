
#include "Context/IContext.h"
#include "TCPService.h"

#include "Networking/IP/IIPLayer.h"
#include "MM/IVirtualMemory.h"
#include "TimerFacility/ITiming.h"
#include "MultiThreading/IMultiThreading.h"

namespace MyOS { namespace Services { namespace Network { namespace TCP {
TCPService* TCPService::instance INITINSTANCE;

TCPService::TCPService( MyOS::Core::IContainer& container ) throw()
: IService( container, VERSION(1,1), ID(), (IService*&) instance )
{
    // todo: in constructor of IService
    this->setNextInChain(0);
}

myos_result_t TCPService::initialize( Context::IContext& context, NVPAIR params[] ) {
myos_result_t r;
r = context.lookup( myos_name_t( IVirtualMemory::ID() ), (IInterface*&) iVirtualMemory );
if (r!=E_MYOS_SUCCESS) return E_MYOS_E_MISREQINTF;

r = context.lookup( myos_name_t( IMultiThreading::ID() ), (IInterface*&) iMultiThreading );
if (r!=E_MYOS_SUCCESS) return E_MYOS_E_MISREQINTF;

r = context.lookup( myos_name_t( ITimerFacility::ID() ), (IInterface*&) iTiming );
if (r!=E_MYOS_SUCCESS) return E_MYOS_E_MISREQINTF;

r = context.lookup( myos_name_t( IIPLayer::ID() ), (IInterface*&) iIPLayer );
if (r!=E_MYOS_SUCCESS) return E_MYOS_E_MISREQINTF;

allocator.init( *iVirtualMemory, 0 );

r = iIPLayer->registerService( *this );

return r;
}

/** Also called after partial init() that fails */
myos_result_t TCPService::deinitialize( Context::IContext& context ) {

if (iIPLayer) iIPLayer->removeService( *this );

   // if (iIPLayer) ((IInterface*)iIPLayer)->release();    

   // if (iVirtualMemory) ((IInterface*)iVirtualMemory)->release();    

return E_MYOS_SUCCESS;
}

}}
}} // namespaces

#ifndef INTERFACE_FWD_DECLS_H
#define INTERFACE_FWD_DECLS_H

/**
 * Forward declarations of all interfaces
 */

namespace MyOS
{
namespace MM
{
    class IVirtualMemory;
    class IPhysicalMemory;
}

namespace InterruptHandling { class IInterruptHandling; }

namespace MultiThreading
{
    class IMultiThreading;
}

namespace MultiProcessing
{
    class Process;
}

namespace Timer
{
    class ITimerFacility;
}

namespace Networking
{
  namespace IP
  {
  class IIPLayer;
  }
}

namespace Drivers {
    class IDriverManager;
}

namespace Context {
    class IContext;
}

namespace IO {
    class IStream;
    class OStream;
    class IOStream;
}

} // MyOS

#endif

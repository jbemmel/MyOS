#ifndef ITiming_H
#define ITiming_H
#include "Core/IInterface.h"

using MyOS::Core::IInterface;

#include "timetypes.h"

namespace MyOS {
namespace Timer {

INTERFACE( ITiming, "cd5a76a0-bf79-4750-8356-9f8a0627465a" )

    /**
     * Returns the current time in the given units
     * 
     * @note Could be placed in a different interface, its unrelated
     */
	virtual u32 now(ETimeUnit units) = 0;

	virtual myos_result_t initTimer(timer_t& timer, ITimerTarget& target) = 0;

	virtual myos_result_t startTimer(timer_t& timer, u32 afterUs) = 0;

	virtual myos_result_t cancelTimer(timer_t& timer) = 0;

	/**
	 * Triggers the given timer, causing a call to ITimerTarget#onTimer
	 * If the timer was set, it is now cancelled 
	 */
	virtual myos_result_t triggerTimer(timer_t& timer) = 0;

	virtual myos_result_t freeTimer(timer_t& timer) = 0;

};

}
} // namespaces
#endif

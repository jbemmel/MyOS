#include "TimerImpl.h"
#include "timetypes.h"
#include "TimerEvent.h"
#include "TSC.h"
#include "TimeUtil.h"

#include "Processor/Processor.h"
#include "MultiThreading/ThreadManager.h"   // call reschedule

// #include "myosconfig.h"    // display, direct hack
#include "Devices/Display/ScreenBuffer.h"

namespace MyOS { namespace Timer {

TimerImpl* TimerImpl::instance = 0;

int TimerImpl::inCallback = 0;

TimerImpl::TimerImpl() : timersource(&c8254)  // INITSECTION
{
   instance = this;  
}

void
TimerImpl::init()  // INITSECTION
{
	TimeUtil::initIPS( 200000000 );  // set reasonable, to prevent crashes
	c8254.init( *this );

	// Whole class should be in INITSECTION...
	class Probe : public ITimerTarget
	{
	public:
		volatile u64 endtime;
		
		inline Probe() : endtime(0) {}
			
		virtual void onTimer() {
			endtime = TSC::read();	
		}
	} probe;

	TimerEvent event;
	event.setCallback( probe );		
	event.setPriority( HeapItem::HIGHEST_PRIORITY ); // set it to fire ASAP
	event.firesAt = 0;
	eventHeap.push( &event );

	bool useAPIC = apicTimer.init( *this );
	if (useAPIC) {
		DPRINTK( "\nUsing local APIC as timer source" );
		// timersource = &apicTimer; do this later, if not it gets reset in probe      
	} else {
		DPRINTK( "\nUsing C8254 chip as timer source" );
	}
   
	Processor::allowInterrupts( true );
	c8254.doIdlePeriod();                    	// some initial overhead...
	u64 starttime = TSC::read();				// take snapshot of TSC just after   
	if (useAPIC) apicTimer.startCountDown(); 	// ..and the APIC too
   
//#ifdef CONFIG_IDisplay
   Devices::Display::ScreenBuffer::getInstance().put(
      0,Devices::Display::ScreenBuffer::E_SCREENWIDTH-1,'\03', 
      Devices::Display::E_RED 
   );
//#endif

   // function cannot return until probe has fired! Waste of cycles, could do
   // much better
	while (!probe.endtime) ASMVOLATILE("hlt");
	
	// There is some overhead before code reaches this, compensated a bit
	// by taking the snapshot *after* the timer has been started
	// Could add correction here if needed	
	u32 ticksInPeriod = (u32)(probe.endtime - starttime - 134);  // assuming <= 32bits
	if (useAPIC) {
		if (apicTimer.probeDone(ticksInPeriod)) {
			timersource = &apicTimer;     // from now on, use this one!
		}  // else e.g. Bochs has no support for it
	}      
	u32 ips = c8254.afterProbe( ticksInPeriod );

	DPRINTK( "\nIPS measured at %d instructions/second", ips );
	TimeUtil::initIPS( ips );
}

/**
 * Communication with synchronous contexts is done using a stack-allocated
 * atomic linked list of 'command' nodes
 */
class CommandNode : public /* AtomicQueue::Node */ Queue::Item
{
public:   
   TimerEvent& event;

   // Cannot use the priority in the event itself, since that would violate
   // heap order (for updating events that are already in the heap)
   u64 time;   // aligned

   enum  E_COMMAND { E_ADD, E_UPDATE, E_REMOVE, E_TRIGGER } command;
   
   // for REMOVE or trigger
   CommandNode( TimerEvent& e, E_COMMAND c ) 
      : event(e), command(c) {}

   // for ADD or UPDATE
   CommandNode( TimerEvent& e, u64 newtime, E_COMMAND c ) 
      : event(e), time(newtime), command(c) {}
   
};

// virtual, from IInterruptContext
/**
 * (usually) **ASYNC** context but also sw triggered
 * 
 * Each timer interrupt results in at most 1 event callback
 * @todo separate adding events from firing events?
 */
void
TimerImpl::onInterrupt( )   // implements IInterruptContext::onInterrupt
{
   //bool hw = IInterruptHandling::isHardwareIRQ();
   //DPRINTK( "\nTimer::onInterrupt hw=%b", hw );

   // process any pending commands
   // DPRINTK( "\nHeapsize=%d", pending.getSize() );
   register CommandNode* c;
   while ((c = (CommandNode*) pending.dequeue()))
   {
      TimerEvent* e = &c->event;
      switch (c->command) 
	  {
      case CommandNode::E_ADD:
	  {
         // Extra check in case event was canceled after 'trigger' ? unlikely...
         // if (e->isCanceled()) continue;      

	      // Priority is set to delta with top() event absolute time, since its only 32 bits
	      e->firesAt = c->time;

         // could call onTimer_addEvent instead (except for recalculated time)
	     TimerEvent *top = eventHeap.top();
         eventHeap.update( e, top ? (c->time - top->firesAt) : 0 );
         break;
	  }

      case CommandNode::E_REMOVE:            
         eventHeap.pop( e );
         DPRINTK( "\nEvent %x removed with force", e );
         break;

      case CommandNode::E_TRIGGER:
         e->doTrigger( eventHeap );
         break;         
      
      case CommandNode::E_UPDATE:
         // ASSERTION( e->inHeap(), E_ERROR ); normally, but not required
         // DPRINTK( "\nTimer::update ticksleft=" ); DPRINTN( c->time - TSC::read() );
		 e->firesAt = c->time;
         eventHeap.update( e, c->time - eventHeap.top()->firesAt );
         break;         
      }
   }
 
   do {
       TimerEvent* next = (TimerEvent*) eventHeap.top();
       if (next) {
           // Before doing any calculations, remove any canceled events
           if ( !next->isCanceled() ) {
               fireEvent( *next );
               break;
           } else {
               next->uncancel();   // clear flag for next time
               eventHeap.pop( next );
           }
       } else {
           // heap empty now, let timer do max period
         CHECKPOINT('T');
        
         // make heart blink
         //#ifdef CONFIG_IDisplay
         Devices::Display::ScreenBuffer::getInstance().xorput(
            0,Devices::Display::ScreenBuffer::E_SCREENWIDTH-1,'#'
         );
         //#endif
                
         timersource->doIdlePeriod();
         break;
       }
   } while (1);
   
   // Finally, check if the thread scheduler needs a call
   // Note: IRQ0 interrupts still locked! And CS still 0x18
   //if ( inCallback==0 ) {
//       inCallback = 1;  // still executing under IRQ0 protection
//       MultiThreading::ThreadManager::checkReschedule();
//       inCallback = 0;
   //}
}

void 
TimerImpl::fireEvent( TimerEvent &event )
{
   s64 time_left = event.firesAt - TSC::read() - TIMER_OVERHEAD_TICKS;
   //DPRINTK( " time-left=%d", (s32) time_left );
   if (time_left < (int) (timersource->getMinPeriodInIPS())) {
      
      // fire now, reprogram timer for next event (again, filter canceled ones)
      // DPRINTK( "\nTimer::fire time_left=%d", (s32) time_left );
      
      eventHeap.pop( &event );
      do {
         TimerEvent* after = (TimerEvent*) eventHeap.top();
         if (!after) {
         	// XX Instead of an idle period, could simply wait until next add
            timersource->doIdlePeriod();            
            // fire! or maybe fire in series ??			
         } else if (after->isCanceled()) {
         	after->uncancel();
            eventHeap.pop( after );
            continue;
         } else {
            time_left += (after->firesAt - event.firesAt);
            timersource->fireAfterCPUCycles( time_left );
         }
         inCallback = 1;
         event.doCallback();   // fire! @todo try..catch around?
         inCallback = 0;       // moved to after scheduler call
         
         // Check again if there are no events, callback may have added some?
         /*if ( eventHeap.top()==0 ) */ return;
      } while (1);
   } else {    // not time yet, reprogram timer and keep on trying
      timersource->fireAfterCPUCycles( time_left );
   }
}

void
TimerImpl::addEvent( TimerEvent& e, u32 usAfterNow )
{
	NOT_IN_IRQ;
	// DPRINTK( "addEvent inCallBack=%b", inCallback );

	if (inCallback) {
	    this->onTimer_addEvent( e, usAfterNow );
	} else {
    	// allocate command node on the stack
    	CommandNode c(e, TimeUtil::convertTime<us>( usAfterNow ) + TSC::read(), CommandNode::E_ADD );
    	// e.uncancel();    // now done after removing canceled event
    	pending.enqueue( c );
    	timersource->trigger( );
	}
}

void
TimerImpl::onTimer_addEvent( TimerEvent& e, u32 usAfterNow )
{
	u64 abstime = TimeUtil::convertTime<us>( usAfterNow ) + TSC::read();
	// e.uncancel();    // now done after removing canceled event
	TimerEvent *top = eventHeap.top();
	e.firesAt = abstime;
	eventHeap.update( &e, top ? top->firesAt - abstime : 0 );
}

void 
TimerImpl::triggerEvent( TimerEvent& e )
{
	// NOT_IN_IRQ; Is allowed, perhaps better not in IRQ0   
    DPRINTK( "\ntriggerEvent inCallBack=%b", inCallback );     // XX Happens recursively a lot!
    if (inCallback) {
        e.doTrigger( eventHeap );
    } else {
        // NOT_IN_IRQ;  // more strict: not in IRQ0
        
        CommandNode c(e,CommandNode::E_TRIGGER);
        pending.enqueue( c );
        timersource->trigger();    // method must not return until command is processed!
    }
}

   
}} // namespace

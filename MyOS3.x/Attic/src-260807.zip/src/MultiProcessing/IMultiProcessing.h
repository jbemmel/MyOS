#ifndef IMultiProcessing_H
#define IMultiProcessing_H

#include "Core/IInterface.h"
#include "Exceptions/MyOSExceptions.h"

using MyOS::Core::IInterface;

namespace MyOS {
namespace MultiProcessing {


class Process;

using Exceptions::OutOfMemoryException;


INTERFACE( IMultiProcessing, "2c902461-c339-4008-ad73-84732a7c9f70" )

	virtual Process& createProcess(u32 allocBlockOrder) 
		throw(OutOfMemoryException) = 0;

	virtual myos_result_t listProcesses(IO::OStream& out) const = 0;

};

}
} // namespaces
#endif

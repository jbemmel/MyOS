#line 1 "Thread.cpp"

#include "Thread.h"
#include "ThreadManager.h"
#include "MultiThreading/MTComponent.h"
#include "MM/memtypes.h"   // for E_KERNEL_MEMORY flag

#include "Timer/ITiming.h"

// To finish init
#include "MM/MMComponent.h"
#include "MultiProcessing/Process.h"      // removeThread
#include "InterruptHandling/IInterruptHandlingImpl.h"   // XX shortcut

namespace MyOS { namespace MultiThreading {

using MM::linadr_t;

#define ITIMING MTComponent::getInstance().iTiming

void*
Thread::operator new( size_t, u32 /* stackorder */ )
{
   // NOTE: Currently *cannot* allocate anything but 1-page stack!
   // currentThread() depends on the fact that ESP is in same page!
   
   // Allocate 2^N linear frames, 1 not mapped and 2^N-1 mapped to kernel
   linadr_t stack = MTComponent::getInstance().iVirtualMemory->allocateStack(0);

   // Allocate Thread structure at the bottom, stack growing upwards from there
   Thread* t = (Thread*) ((u32) stack + (1UL<<(0+12)) - sizeof(Thread));
   t->stackorder = 0; // stackorder;
   return t;
}

void
Thread::operator delete( void* _this )
{
   // DPRINTK( "\nThread::delete this=%x esp=%x", _this, Processor::ESP() );
   
   ASSERTION( _this != &currentThread(), E_ERROR );    // don't kill yourself!
   Thread* t = (Thread*) _this;
   MTComponent::getInstance().iVirtualMemory->freeStack( 
      (void*) ((u32)_this & 0xFFFFF000), t->stackorder );
}

// used for initial thread
Thread::Thread()   // INITSECTION
: state(E_RUNNING), next(0), esp(0) // set when switch to next thread is made
, homeContext(0), visitedContext(0)
, toDelete(0)
, allocator( *MTComponent::getInstance().iVirtualMemory, 0 ), locks(1)
{
   // XX should really clear what needs clearing here...

   // DPRINTK( "\ncurThread=%x -sizeof(Thread)=%x", &currentThread(), -sizeof(Thread) );
   
   // start quantum timer
   // XX *SHOULD NOT FIRE BEFORE PROCESS INIT FINISHES*
   // this->schedule( 10000 );   // ::TimerEvent, XX hardcoded
   
   ITIMING->initTimer( timer, *this );
}


Thread::Thread( u32 allocOrder ) 
: state(E_CREATED), next(0), esp((u32*)this)
, homeContext(0), visitedContext(0)
, toDelete(0)
, allocator( *MTComponent::getInstance().iVirtualMemory, allocOrder )
, locks(1)
{
	ITIMING->initTimer( timer, *this );
}

// virtual, called in context of *another* thread!
Thread::~Thread() throw()
{
   ASSERTION( this != &currentThread(), E_ERROR );    // don't kill yourself!
   ASSERTIONv( this->state == E_ENDED, E_ERROR, this->state );
   ASSERTIONv( locks<=0, E_CRITICAL, locks );
   
   // DPRINTK( "\n~Thread this=%x", this );

   ITIMING->freeTimer( timer );
   

   homeContext->removeThread( *this );
      
   this->state = E_DESTRUCTED;
   // calls ~ByteAllocator which frees all memory      
}

// virtual callback, in IRQ context
void
Thread::onTimer( )
{
	// DPRINTK( "\nThread(%x)::onTimer state=%d stack=%x", this, state, Processor::ESP() );
  
	// in any case, request that the scheduler be called after this
    // (or *after* processing?)
	// ThreadManager::requestReschedule();
	
	switch ( this->state )
	{
	case E_RUNNING:	// i.e. quantum ended
		ASSERTION( &currentThread() == this, E_CRITICAL );
		this->state = E_READY;	   // policy should choose upon IRQschedule() 
		//
		// DONT call into policy, policy gets its chance in selectNext
		//
		// ThreadManager::threadReady( *this );		
		break;
		
	case E_READY:  // i.e. start() called
		currentThread().state = E_READY;	// from E_RUNNING, until selected
		ThreadManager::threadReady( *this );
		break;

	case E_SUSPENDING: // i.e. suspend() called, this==current
	    this->state = E_SUSPENDED;
	    // Dont tell policy
	    // Dont start any timer
	    break;

	case E_SUSPENDED:  // i.e. wakeup() called
	    currentThread().state = E_READY;   // from E_RUNNING, until selected
	    this->state = E_READY;
	    ThreadManager::threadReady( *this );	    
	    break;
	    
	case E_SLEEPY:  // i.e. sleep() called
		ASSERTION( &currentThread() == this, E_CRITICAL );
		this->state = E_SLEEPING;
		// ThreadManager::startWaiting( *this );     // XX needed? current policy does not use it
		ITIMING->startTimer( this->timer, this->sleeptime );	// in IRQ
		break;

	case E_SLEEPING:	// i.e. timeout or wakeup() after sleep()

		// Check for wake-before-sleep situation
		//
		// This occurs when the timer fires after onTimer_schedule above,
		// before ThreadManager::finishINT gets a chance to run select()
		// Seems solved now, by putting the schedule() *after* esp swap
		ASSERTIONv( &currentThread() != this, E_CRITICAL, this );
		
		// CANCEL(!) quantum timer of current thread
		ITIMING->cancelTimer( currentThread().timer );  // in IRQ
		
		currentThread().state = E_READY;	// from E_RUNNING, until selected
		this->state = E_READY;
		ThreadManager::threadReady( *this );
		break;

	case E_ENDED:
	    {
	        // TODO: Think about semantics of onEndThread...        
	        Thread& _next = ThreadManager::endThread( *this );
	        _next.toDelete = this;
	        break;
	    }		
		
	default:
		ASSERTIONv( "Unexpected thread state"==0, E_CRITICAL, this->state );
	}
	
	// Current thread must be READY or SLEEPING or SUSPENDED
	ThreadManager::reschedule();
}

void
Thread::init( IRunnable& runnable, NVPAIR params[], size_t paramCount )
{
   ASSERTION( state == E_CREATED, E_ERROR ); // for now, no reuse yet
    // DPRINTK( "\nThread(%x)::init params = %x %x", this, &runnable, params );   

    // Stackframe must match 'select' epilogue code !!
    esp = (u32*) this; // reinit, for reusing threads

    // GCC likes stack aligned to 16-byte; trial and error...
    esp -= 1;

    // Don't reverse the order of the parameters!
    if (params) for (int p=paramCount-1; p>=0; --p)
    {
        (*(--esp)) = (u32) params[p].getValue();
        (*(--esp)) = (u32) params[p].getName();
    }
    (*(--esp)) = (u32) (esp+1); // point to copy params on new stack
    (*(--esp)) = (u32) &runnable;
    (*(--esp)) = (u32) this;
    (*(--esp)) = 0; // bogus caller address ?? (could be &exit)
    (*(--esp)) = (u32) startThread; // "return" address

    // conform to 'select' epilogue code, which pops some dwords (see asm list..)
    esp -= 3; // other compiler flags give other results :( DANGER ):

    // .. and/or perhaps curProcess.attachThread( *this )
    homeContext = visitedContext = &MultiProcessing::Process::getCurrent();
    state = E_READY;
}

// simple, used by process and Thread::start below
void
Thread::start()
{
   ASSERTION( &currentThread() != this, E_ERROR );
   ITIMING->triggerTimer( timer );
}

// virtual
void
Thread::start( IRunnable& r, NVPAIR params[], size_t paramCount )
{
	this->init( r, params, paramCount );
	this->start();
}

// static, REGPARM(0) to ensure all params are passed on stack
void
Thread::startThread( Thread& _this, IRunnable& runnable, NVPAIR params[] )
{
    DPRINTK( "\nstartThread reached, thread=%x CS=%x", &_this, Processor::CS() );

    // re-enable IRQ0
    InterruptHandling::IInterruptHandlingImpl::fakeIretIRQ0();
    
    // Switch to regular CS (@todo easier way? far return?)
    ASMVOLATILE( "ljmp $8, $regularCS; regularCS:" );
    try
    {
        _this.exitcode = runnable.run( params );
        DPRINTK( "\nExitcode: %d", _this.exitcode );
    }
    catch (ThreadExitException &tee)
    {
        // this is normal, thrown in exit() below
        DPRINTK( "#2f#\nCaught ThreadExitException in thread(%x).run", &_this );
        _this.exitcode = tee.getExitCode();
    }
    catch (...)
    {
        DPRINTK( "#4f#\nCaught exception in thread(%x).run", &_this );
    }
    _this.state = E_ENDED;
    DPRINTK( "\nThread %x ended", &_this );
    ITIMING->triggerTimer( _this.timer );

    BUG( "@#ERROR#@ should not return here!" );
}

/***
 * NOTE: Don't touch this routine for debugging, the size of the stackframe
 * is added in init()!
 */
void
Thread::select( u32 quantumUs )  // REGPARM(2)
{
	this->state = E_SELECTED;  // not really needed

	Thread &cur = currentThread();
	
   // State of current thread must be set to E_WAITING or E_READY before this
   // DPRINTK( "\nselect->schedule this=%x quantum=%d esp=%x", this, quantumUs, esp );

   // save(!) current ESP for current thread, also save for first thread
   // since space for Thread instance is reserved in DoDecompress
   cur.esp = Processor::ESP();

   // Check for process change too
   if ( cur.visitedContext != this->visitedContext ) {
       this->visitedContext->taskSwitch();
   }
   Processor::setESP( this->esp );

   /**
    * This is the only point where state gets set to 'RUNNING'
    * Do it after starting the timer? it may fire immediately (should be prevented!)
    */  
   this->state = Thread::E_RUNNING;
      
   /**
    * At this point, the stack has changed, but 'this' should still point to the same thread
    */  
   ITIMING->startTimer( timer, quantumUs );	// after switch of esp! Critical
											// for preventing wake-before-sleep

   // check for thread to delete
   Thread* t;
   if (RARELY((t=this->toDelete))) {
      this->toDelete = 0;
      t->asyncDone(true);   // deletes iff locks becomes 0
   }
}

// virtual 
void* 
Thread::allocate( size_t bytes ) throw (OutOfMemoryException) {
   // DPRINTK( "\nThread::allocate size=%d", bytes );
   return allocator.allocateAutoSize( bytes );  
}   

// virtual 
void 
Thread::free( void* mem ) {
   // DPRINTK( "\nThread::free this=%x mem=%x", this, mem );
   return allocator.freeAutoSize( mem );  
}

// virtual 
bool 
Thread::usSleep( u32 us, u32 usAccuracy /* not used yet... */ )
{
	NOT_IN_IRQ;
   
	// DPRINTK( "\nusSleep us=%d this=%x", us, this );

	// XX Tweak for time keeping overhead
#ifdef DEBUG	
	if (us > 38) us -= 38;
#else	// RELEASE
	if (us > 30) us -= 30;
#endif	
   
	// TODO: Watch out for wake-before-sleep 
	this->sleeptime = us;
	this->state = E_SLEEPY;
	ITIMING->triggerTimer( timer );
   
	// DPRINTK( "\nSleep done %b (sleeptime=%d)", this->sleeptime == us, sleeptime );
	return this->sleeptime == us;    // set to 0 in wakeup() below
}

// virtual
void
Thread::suspend()
{
    ASSERTION( this == &currentThread(), E_ERROR );
    
    DPRINTK( "\nsuspend this=%x cur=%x ESP=%x CS=%x", 
            this, &currentThread(), Processor::ESP(), Processor::CS() );
    
    this->state = E_SUSPENDING;
    ITIMING->triggerTimer( timer );
}

// virtual
bool
Thread::wakeup()
{
	ASSERTIONv( state==E_SLEEPING || state==E_SUSPENDED, E_ERROR, state );
   
	DPRINTK( "\nwakeup this=%x cur=%x ESP=%x CS=%x", 
	    this, &currentThread(), Processor::ESP(), Processor::CS() );
   
	switch( this->state )
	{
	case E_SLEEPING:    // i.e. waiting for timer
	    this->sleeptime = 0;
	    // no break
	    
	case E_SUSPENDED:   // i.e. suspended waiting for wakeup		
		// state remains same, onTimer changes it
		ITIMING->triggerTimer( timer );   // may be running, or not, does not matter
		return true;
		
	default:
	    DPRINTK( "\n#4f#Wakeup failed! state=%X", state );
	    return false;	    
   }
}

// virtual
void
Thread::yield( IThread* to ) 
{
   NOT_IN_IRQ;      
   
   if (to) {
      ASSERTION( ((Thread*)to)->state == E_READY, E_ERROR );
      // Notify the policy, then switch (here is ok?) ?
      // Perhaps better to set the timer on the 'to' thread
      BUG( "TODO: Yield to thread, policy.onHandover()" );    
   } else {
      // simply force the timer to expire now
      CHECKPOINT('y');
      ITIMING->triggerTimer( timer );
   }   
}

// virtual
void
Thread::exit( int ec ) throw (ThreadExitException) // NORETURN
{
   ASSERTION( state==E_RUNNING, E_ERROR );   
   ASSERTIONv( toDelete==0, E_ERROR, toDelete );
   DPRINTK( "\nThread::exit this=%x code=%d", this, ec );
   
   this->state = E_ENDED;
   throw ThreadExitException(ec);
}

// virtual 
bool 
Thread::registerIdleWork( void (*f)() )
{
   // TODO
   return false;  
}

// static, called at end of MyOSMain()
void
Thread::becomeIdle( unsigned idleQuantumMs ) // NORETURN

{
    // Finish kernel init   
    MM::MMComponent::getInstance().freeInitPages();

    Thread* cur = &currentThread();

    // Start quantum timer for init thread here instead !!
    DPRINTK( "\nbecomeIdle(%x) starting %dms timer...", cur, idleQuantumMs );
    if (idleQuantumMs>0)
    {
        ITIMING->startTimer( cur->timer, 1000*idleQuantumMs );
    }
    try
    {
        PRINTK( "\nIDLE(%x) running...", cur );
        int count=0;
        while (1)
        {
            //  
            if ((++count & 0xfffff)==0)
            {
#ifdef DEBUG
                CHECKPOINT('i');
#else      
                PRINTK("i"); // show life
#endif
            }
        }
    }
    catch (...)
    {
        DPRINTK( "Caught exception in IDLE" );
    }
    ASMVOLATILE( "hlt" );
    while (1);
}

}} // namespace
